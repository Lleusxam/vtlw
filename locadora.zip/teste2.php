<?php
include("config.php");
$consulta = $conexao->query("select * from tb_clientes");
?>
<html>
<meta charset="utf-8">


<?php while($resultado = $consulta->fetch_assoc()){ ?> 

<?php echo $resultado['CLI_NOME']; ?> | 
<?php echo $resultado['CLI_LOGRADOURO']; ?>, <?php echo $resultado['CLI_NUMERO']; ?>
<br>

<?php } ?>
olá
</html>