<?php

//setcookie("usuario", "ari", time()+172800); 

//echo $_COOKIE["usuario"];

session_start();
$_SESSION['nome'] = "Ari111";
