<?php
include("config.php");
include("verifica.php");
$codigo = $_GET['codigo'];

$consulta2 = $conexao->query("select * from tb_clientes join tb_bairros on cli_bai_codigo = bai_codigo join tb_cidades on bai_cid_codigo = cid_codigo where CLI_CODIGO = $codigo");
$resultado2 = $consulta2->fetch_assoc();

?>
<html>
<meta charset="utf-8">
<h1>Ver Cliente</h1>
Nome: <?php echo $resultado2['cli_nome']; ?><br>
CPF: <?php echo $resultado2['cli_cpf']; ?> <br>
Logradouro: <?php echo $resultado2['cli_logradouro']; ?>, <?php echo $resultado2['cli_numero']; ?> <br>
CEP: <?php echo $resultado2['cli_cep']; ?><br>
Nascimento: <?php echo $resultado2['cli_dtnasc']; ?> <br>
Bairro: <?php echo $resultado2['bai_bairro']; ?><br>
Cidade: <?php echo $resultado2['cid_cidade']; ?><br>

<a href="clientes.php">< Voltar</a>
</html>