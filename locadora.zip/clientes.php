<?php
include("config.php");
include("verifica.php");
$consulta = $conexao->query("select *,date_format(cli_dtnasc,'%d/%m/%Y') as data2 from tb_clientes join tb_bairros on cli_bai_codigo = bai_codigo order by cli_codigo");

if(isset($_GET['excluir'])){
	$codigo = $_GET['excluir'];
	if($consulta2 = $conexao->query("delete from tb_clientes where cli_codigo = $codigo")){
		header("Location: clientes.php");
	}
	else {
		echo "Não foi possível excluir!";
	}
}

?>
<html>
<meta charset="utf-8">
<h1>Listagem de Clientes</h1>
<table border='1'>
	<tr>
		<td>#</td>
		<td>Nome</td>
		<td>Endereço</td>
		<td>Data de Nascimento</td>
		<td>Ações</td>
	</tr>
<?php while($resultado = $consulta->fetch_assoc()){ ?>
	<tr>
		<td><?php echo $resultado['cli_codigo']; ?></td>
		<td><?php echo $resultado['cli_nome']; ?></td>
		<td><?php echo $resultado['cli_logradouro']; ?>, <?php echo $resultado['cli_numero']; ?> - <?php echo $resultado['bai_bairro']; ?></td>
		<td><?php echo $resultado['data2']; ?></td>
		<td>&nbsp;<a href="cliente-editar.php?codigo=<?php echo $resultado['cli_codigo']; ?>"><img src="imagens/editar.png" width="16"></a> 
		
		<a href="?excluir=<?php echo $resultado['cli_codigo']; ?>" onclick="return confirm('Tem certeza?')">
		<img src="imagens/excluir.png" width="16"></a>
		
		<a href="cliente-ver.php?codigo=<?php echo $resultado['cli_codigo']; ?>">
			<img src="imagens/ver.png" width="16"></td>
		</a>
	</tr>
<?php } ?>
</table>
<a href="cliente-novo.php">Novo cliente</a> | 
<a href="principal.php">< Voltar</a>

</html>