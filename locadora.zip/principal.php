<?php
include("verifica.php");
?>
<html>
<meta charset="utf-8">
<h1>Bem-vindo, <?php echo $_SESSION['nome']; ?>!</h1>

<a href="clientes.php">Listagem de clientes</a>
<a href="filmes.php">Listagem de filmes</a>
<a href="sair.php">Sair</a>
<br>
Logado desde: <?php echo $_SESSION['datalogin']; ?>
</html>