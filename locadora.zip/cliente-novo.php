<?php
include("config.php");
include("verifica.php");
if(isset($_POST['nome'])){
	extract($_POST);
	if($consulta = $conexao->query("INSERT INTO TB_CLIENTES (cli_nome, cli_cpf, cli_bai_codigo, cli_logradouro, cli_numero, cli_cep, cli_dtnasc) VALUES ('$nome','$cpf','$bairro','$logradouro','$numero','$cep','$dtnasc')")){
		header("Location: clientes.php");
	}
	else {
		echo "Não foi possível cadastrar!";
	}
}

$consulta2 = $conexao->query("select * from tb_bairros");
?>
<html>
<meta charset="utf-8">
<h1>Novo Cliente</h1>
<form action="?" method="POST">
	Nome <input type="text" name="nome"><br>
	CPF <input type="text" name="cpf"><br>
	Logradouro <input type="text" name="logradouro"><br>
	Número <input type="text" name="numero"><br>
	CEP <input type="text" name="cep"><br>
	Nascimento <input type="date" name="dtnasc"><br>
	Bairro
	<select name="bairro">
	<?php while($resultado2 = $consulta2->fetch_assoc()){ ?>
		<option value="<?php echo $resultado2['bai_codigo']; ?>"><?php echo $resultado2['bai_bairro']; ?></option>
	<?php } ?>
	</select>
	<br>
	<input type="submit" value="CADASTRAR"><br>
</form>
<a href="clientes.php">< Voltar</a>
</html>