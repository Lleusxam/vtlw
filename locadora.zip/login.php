<?php
include("config.php");
$erro=0;
if(isset($_POST['usuario'])){
	extract($_POST);
	$consulta = $conexao->query("select * from tb_clientes where cli_usuario = '$usuario' and cli_senha = '$senha'");
	if($resultado = $consulta->fetch_assoc()){
		$_SESSION['usuario'] = $resultado['cli_usuario'];
		$_SESSION['nome'] = $resultado['cli_nome'];
		$_SESSION['datalogin'] = date();
		header("Location: principal.php");
	}
	else {
		$erro=1;
	}
}

?>
<html>
<meta charset="utf8">
<form action="?" method="POST">
<h1>Login</h1>
<?php if($erro==1) echo "<span style='color:red'>Usuario ou senha inválida, tente novamente.</span><br>"; ?>
usuario: <input type="text" name="usuario"><br>
senha: <input type="password" name="senha"><br>
<input type="submit" value="logar">
</form>
</html>