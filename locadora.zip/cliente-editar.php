<?php
include("config.php");
include("verifica.php");
$codigo = $_GET['codigo'];

if(isset($_POST['nome'])){
	extract($_POST);
	if($consulta = $conexao->query("update tb_clientes set cli_nome = '$nome', cli_cpf = '$cpf', cli_bai_codigo = '$bairro', cli_logradouro = '$logradouro', cli_numero = '$numero', cli_cep = '$cep', cli_dtnasc = '$dtnasc' where cli_codigo = $codigo")){
		header("Location: clientes.php");
	}
	else {
		echo "Não foi possível alterar!";
	}
}

$consulta2 = $conexao->query("select * from tb_clientes where cli_codigo = $codigo");
$resultado2 = $consulta2->fetch_assoc();

$consulta3 = $conexao->query("select * from tb_bairros");

?>
<html>
<meta charset="utf-8">
<h1>Editar Cliente</h1>
<form action="?codigo=<?php echo $codigo; ?>" method="POST">
	Nome <input type="text" name="nome" value="<?php echo $resultado2['cli_nome']; ?>"><br>
	CPF <input type="text" name="cpf" value="<?php echo $resultado2['cli_cpf']; ?>"><br>
	Logradouro <input type="text" name="logradouro" value="<?php echo $resultado2['cli_logradouro']; ?>"><br>
	Número <input type="text" name="numero" value="<?php echo $resultado2['cli_numero']; ?>"><br>
	CEP <input type="text" name="cep" value="<?php echo $resultado2['cli_cep']; ?>"><br>
	Nascimento <input type="date" name="dtnasc" value="<?php echo $resultado2['cli_dtnasc']; ?>"><br>
	Bairro 
	<select name="bairro">
		<?php while($resultado3 = $consulta3->fetch_assoc()){ ?>
		<option value="<?php echo $resultado3['bai_codigo']; ?>" <?php
		if($resultado3['bai_codigo'] == $resultado2['cli_bai_codigo']) echo "selected"; ?>><?php echo $resultado3['bai_bairro']; ?></option>
		<?php } ?>
	</select>
	
	<br>
	<input type="submit" value="SALVAR"><br>
</form>
<a href="clientes.php">< Voltar</a>
</html>