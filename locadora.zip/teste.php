<?php
include("config.php");

$consulta = $conexao->query("select * from tb_clientes where CLI_CODIGO = 4");
$resultado = $consulta->fetch_assoc();
?>
<html>
<meta charset="utf-8">
Olá, <?php echo $resultado['CLI_NOME']; ?>!!
<br>
<?php echo $resultado['CLI_LOGRADOURO']; ?>, <?php echo $resultado['CLI_NUMERO']; ?>
</html>