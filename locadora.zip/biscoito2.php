<?php
//echo "olar ";
//echo $_COOKIE["usuario"];
session_start();
echo $_SESSION['nome'];
